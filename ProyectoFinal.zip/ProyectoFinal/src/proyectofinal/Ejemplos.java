/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectofinal;

import java.util.Scanner;

/**
 *
 * @author Cody
 */
public class Ejemplos {

    public static Scanner sc = new Scanner(System.in);

    public void IfElse() {
        System.out.println("SUGERENCIAS PARA EL CLIMA");

        System.out.println("Ingresa la temperatura del dia por favor: ");
        int tem = sc.nextInt();

        if (tem > 25) {
            System.out.println("Puedes ir a los playantiales");
        } else if (tem > 15) {
            System.out.println("Puedes ir al parque");
        } else if (tem <= 5) {
            System.out.println("Puedes quedarte en saca y tomar un chocolatito caliente");
        }
    }
    
    public void IfElse2(){
        System.out.println("SUGERENCIA DE DESPLASAMIENTO");
        
        System.out.println("Ingresa distancia del lugar (km): ");
        int dis = sc.nextInt();
        
        if (dis <= 4){
            System.out.println("Puedes ir caminando");
        }else if(dis > 5 && dis < 10){
            System.out.println("Puedes ir en bicicleta");
        }else if(dis >=10 ){
            System.out.println("puedes ir en moto o automovil");
        }else if (dis > 100 ){
            System.out.println("puedes ir en avion ");
        }
    }
    
    public void IfElse3(){
        System.out.println("SE PUEDE DIVIDIR EL NUMERO EN 5");
        
        System.out.println("ingresa un numero");
        int num = sc.nextInt();
        
        int div = 5/num;
        
        if (num > 0){
            System.out.println("si puede dividirse y es " + div);
        }else if(num == 0){
            System.out.println("no puede dividirse el cero");
        }
    }
    
    public void Switch() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Menu de top 5 juegos de cada genero:"
                + "\n\n1. Arcade: "
                + "\n2. Plataformas: "
                + "\n3. Disparos: "
                + "\n4. Pelea: "
                + "\n5. Salir"
                + "\n\nElija una opcion por favor");

        int opcion = scanner.nextInt();

        switch (opcion) {
            case 1:
                System.out.println("\nGun Fight"
                        + "\nNight Driver"
                        + "\nBreakout"
                        + "\nSpace Invaders"
                        + "\nAsteroids");
                break;
            case 2:
                System.out.println("\nOri and the Will of the Wisps"
                        + "\nAstro Bot Rescue Mission"
                        + "\nFez"
                        + "\nCeleste "
                        + "\nSonic Mania Plus ");
                break;
            case 3:
                System.out.println("\nDoom Eternal "
                        + "\nBorderlands 3"
                        + "\nQuake"
                        + "\nHalo Reach"
                        + "\nDusk");
                break;
            case 4:
                System.out.println("\nTekken 3"
                        + "\nSoulCalibur"
                        + "\nSuper Street Fighter II"
                        + "\nSuper Smash Bros. Melee"
                        + "\nThe King of Fighters '98");
            case 5:

                break;
            default:
                System.out.println("por favor ingrese correctamente un indice numerico");
        }
    }

    public static void FOR() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingresa un numero: ");
        int numero = scanner.nextInt();
        int x = 0;
        for (x = 1; x <= numero; x++) {
            System.out.printf("%d \t", x);
            if (x % 5 == 0) {
                System.out.printf("\n");

            }

        }

    }

    // Escribir un programa que imprime los números del 1 a n, donde n 
    // es la cantidad de días que tiene un mes que el usuario selecciona 
    // previamente.
    public static void FOR2() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("DIAS QUE TIENE UN MES");

        System.out.println("Que mes desae: ");
        int x, dias = 0;
        int aa = 2022;
        int m, mes = scanner.nextInt();

        if (mes == 1) {
            System.out.println("Enero");
        }
        if (mes == 2) {
            System.out.println("Febrero");
        }
        if (mes == 3) {
            System.out.println("Marzo");
        }
        if (mes == 4) {
            System.out.println("Abril");
        }
        if (mes == 5) {
            System.out.println("Mayo");
        }
        if (mes == 6) {
            System.out.println("Junio");
        }
        if (mes == 7) {
            System.out.println("Julio");
        }
        if (mes == 8) {
            System.out.println("Agosto");
        }
        if (mes == 9) {
            System.out.println("Septiembre");
        }
        if (mes == 10) {
            System.out.println("Octubre");
        }
        if (mes == 11) {
            System.out.println("Noviembre");
        }
        if (mes == 12) {
            System.out.println("Diciembre");
        }

        if (mes == 1 || mes == 3 || mes == 5
                || mes == 7 || mes == 8 || mes == 10
                || mes == 12) {
            dias = 31;

        }
        if (mes == 4 || mes == 6 || mes == 9
                || mes == 11) {
            dias = 30;
        }
        if (mes == 2) {
            dias = 28;
        }

        for (x = 1; x <= dias; x++) {
            System.out.printf("%d\t", x);
            if (x % 7 == 0) {
                System.out.printf("\n");
            }

        }

    }

    // Diseñar una aplicacion que muestre la tabla de multiplicar de x numero 
    // hasta x numero.
    public static void FOR3() {

        Scanner scanner = new Scanner(System.in);

        System.out.println("TABLAS DE MULTIPLICAR A ELECCION");
        
        System.out.println("Ingresar primer numero: ");
        int xumero = scanner.nextInt();
        int x = 0;
        System.out.println("Ingresar segundo numero: ");
        int numero = scanner.nextInt();
        int n = 0;
        for (x = 1; x <= xumero; x++) {
            for (n = 1; n <= numero; n++) {
                System.out.println(x + "x" + n + "\n" + " = " + (x * n));

            }
        }
    }

    public static void WHILE() {

        Scanner scanner = new Scanner(System.in);
        
        System.out.println("SECUENCIA DE UN NUMERO");
        
        System.out.println("Ingresa un numero: ");
        int numero = scanner.nextInt();
        int i = 0;
        while (i < numero) {
            System.out.println("i: " + i);
            i++;

        }
    }

    public static void WHILE2() {
        
        System.out.println("NUMEROS QUE SIGUEN DE LOS NUMEROS ELEJIDOS");

        Scanner scanner = new Scanner(System.in);
        int contador;
        int fin;
        System.out.println("Por favor ingrese el valor inicial: ");
        contador = scanner.nextInt();
        System.out.println("Por favor ahora ingrese el valor final: ");
        fin = scanner.nextInt();
        while (contador <= fin) {
            System.out.println("Valor actual de la iteracion " + contador);
            contador++;

        }
    }

    public static void WHILE3() {

        System.out.println("EL VALOR EN BINARIO DE UN NUMERO");
        
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese una cantidad: ");
        int numero1 = scanner.nextInt();
        String binario = "";
        while (numero1 > 0) {
            binario = numero1 % 2 + binario;
            numero1 /= 2;
        }
        System.out.println("Numero binario: " + binario);

    }
    
    public void SwitchIfEsle() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ejemplod de If Else"
                + "\n\n1. Ejemplo 1 "
                + "\n2. Ejemplo 2: "
                + "\n3. Ejemplo 3: "
                + "\n4. Salir"
                + "\n\nElija una opcion por favor");

        int opcion = scanner.nextInt();
     
        switch (opcion) {
            case 1:
                IfElse();
                break;
            case 2:
                IfElse2();
                break;
            case 3:
                IfElse3();
                break;
            case 4:
                Switch();
                break;
            default:
                System.out.println("por favor ingrese correctamente un indice numerico");
        }
    }
    public void SwitchWhile() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ejemplod de While"
                + "\n\n1. Ejemplo 1 "
                + "\n2. Ejemplo 2: "
                + "\n3. Ejemplo 3: "
                + "\n4. Salir"
                + "\n\nElija una opcion por favor");

        int opcion = scanner.nextInt();
     
        switch (opcion) {
            case 1:
                WHILE();
                break;
            case 2:
                WHILE2();
                break;
            case 3:
                WHILE3();
                break;
            case 4:
                Switch();
                break;
            default:
                System.out.println("por favor ingrese correctamente un indice numerico");
        }
    }
    
    public void SwitchFor() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Menu de top 5 juegos de cada genero:"
                + "\n\n1. Ejemplo 1: "
                + "\n2. Ejemplo 2: "
                + "\n3. Ejemplo 3: "
                + "\n4. Salir"
                + "\n\nElija una opcion por favor");

        int opcion = scanner.nextInt();

        switch (opcion) {
            case 1:
                FOR();
                break;
            case 2:
                FOR2();
                break;
            case 3:
                FOR3();
                break;
            case 4:
                Switch();
                break;
            default:
                System.out.println("por favor ingrese correctamente un indice numerico");
        }
    }

}
