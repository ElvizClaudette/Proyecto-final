package proyectofinal;

import java.util.Scanner;

public class ProyectoFinal {

    public static void main(String[] args) {
    menu();
    }

    public static void menu() {
        Ejemplos e = new Ejemplos();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Menu de Ejemplos de Programacion: "
                + "\n\n1. Ejemplo de if else: "
                + "\n2. Ejemplo de switch: "
                + "\n3. Ejemplo de for: "
                + "\n4. Ejemplo de while: "
                + "\n5. Salir"
                + "\n\nElija una operacion del menu");

        int opcion = scanner.nextInt();
        //estructura para organizar opiniones 
        switch (opcion) {
            case 1:
                e.SwitchIfEsle();
                break;
            case 2:
                e.Switch();
                break;
            case 3:
                e.SwitchFor();
                break;
            case 4:
                e.SwitchWhile();
            case 5:
                
                break;
            default:
                System.out.println("por favor ingrese correctamente un indice numerico");
        }
    }
}
